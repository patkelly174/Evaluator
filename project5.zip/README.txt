The only thing you must download to run this code is the latest version of
Python. You then need to download the links.srt.gz file from moodle and add it into the src directory.
Then open a terminal window in the src directory and run the program using python3 evaluator.py